Ten parametr kontroluje skalę modelu bytu, jeśli byt został utworzony przy użyciu jajka spawnującego lub przy rozmnażaniu dwóch bytow.
