Ten parametr określa, w jakich perspektywach będą odtwarzane animacje przedmiotów.
"All Perspectives" odtworzy animacje we wszystkich perspektywach
"First Person" będzie odtwarzać animacje tylko w pierwszej osobie
"Third/Second Person" będzie odtwarzać animacje tylko wtedy, gdy nie są w pierwszej osobie.



