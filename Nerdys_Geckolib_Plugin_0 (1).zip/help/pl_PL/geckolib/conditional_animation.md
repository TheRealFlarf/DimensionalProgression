Gdy wartość nazwy animacji jest zwrócona, dana animacja zostanie odtworzona dla danego bytu.

